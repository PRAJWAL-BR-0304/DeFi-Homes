import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please connect to Supabase from the StackBlitz interface.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// Add a helper function to check connection
export const checkSupabaseConnection = async () => {
  try {
    const { error } = await supabase.from('properties').select('id').limit(1);
    if (error) throw error;
    console.log('Supabase connection successful');
    return true;
  } catch (error) {
    console.error('Supabase connection error:', error);
    return false;
  }
};